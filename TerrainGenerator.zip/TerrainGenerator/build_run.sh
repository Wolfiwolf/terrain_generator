if g++ src/*.cpp src/*/*.cpp src/*/*/*.cpp src/vendor/glad/glad.c -std=c++17 -lglfw -lGL -lX11 -lpthread -ldl -o terrain_generator;
then
	clear
	echo '-----RUN-----'
	./terrain_generator
	echo ''
	echo '-------------'
fi
