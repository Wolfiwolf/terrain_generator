#pragma once

#include <sstream>
#include <string>

enum EventType
{
    MOUSE_PRESSED,
    MOUSE_RELEASED,
    MOUSE_MOVED,
    KEY_PRESSED,
    KEY_RELEASED,
    WINDOW_CLOSED
};

class Event
{
public:
    virtual ~Event()
    {

    }
    virtual std::string to_string() const = 0;

    virtual EventType get_type() const = 0;
};
