#include "Camera.hpp"

#include <iostream>
#include <cmath>

Camera::Camera(int framebuffer_width, int framebuffer_height)
    : m_position(0.0f)
    , m_ortho_position(0.0f)
    , m_speed(0.0f)
    , m_angle_x(0.0f)
{
    m_ortho_view = glm::translate(glm::mat4(1.0f), m_ortho_position);
    m_ortho_proj = glm::ortho(0.0f, (float)SCREEN_WIDTH, 0.0f, (float)SCREEN_HEIGHT, -1.0f, 1.0f);


    m_front = glm::vec3(0.0f, 0.0f, -1.0f);

    m_perspective_view = glm::lookAt(m_position, m_position + m_front, {0.0f, 1.0f, 0.0f});
    m_perspective_proj = glm::perspective(glm::radians(50.0f), (float)framebuffer_width/framebuffer_height, 0.001f, 1000.0f);

    update_mvp();
}

Camera::~Camera()
{

}

void Camera::update()
{
    update_mvp();
}

void Camera::add_shader(Shader* shader, ProjectionType type)
{
    if(type == ORTHO)
    {
        shader->bind();
        shader->set_uniform_4mat("u_projection_matrix", m_ortho_proj);
        m_ortho_shaders.push_back(shader);
    }
    else
    {
        shader->bind();
        shader->set_uniform_4mat("u_projection_matrix", m_perspective_proj);
        m_perspective_shaders.push_back(shader);
    }
}

void Camera::set_position(const glm::vec3& pos)
{
    m_position = pos;

    m_perspective_view = glm::lookAt(m_position, m_position + m_front, {0.0f, 1.0f, 0.0f});
}

void Camera::move(Direction dir)
{
    switch(dir)
    {
        case FORWARD:
            move_forward();
            break;

        case BACKWARD:
            move_backward();
            break;

        case LEFT:
            move_left();
            break;

        case RIGHT:
            move_right();
            break;

        case UP:
            move_up();
            break;

        case DOWN:
            move_down();
            break;

        default:
            std::cout << "ERROR: CAMERA DIRECTION NOT VALID!\n";
            break;
    }
    m_perspective_view = glm::lookAt(m_position, m_position + m_front, {0.0f, 1.0f, 0.0f});
}

void Camera::look(float x, float y)
{
    m_angle_x += x;

    m_front.x = cos(glm::radians(m_angle_x));
    m_front.z = sin(glm::radians(m_angle_x));


    if(y < 0.0f)
        m_front.y = m_front.y + y < -1.0f ? -1.0f : m_front.y + y;

    else
        m_front.y = m_front.y + y > 1.0f ? 1.0f : m_front.y + y;

    m_perspective_view = glm::lookAt(m_position, m_position + m_front, {0.0f, 1.0f, 0.0f});

}

//PRIVATE
void Camera::update_mvp()
{
    for(Shader* shader : m_ortho_shaders)
    {
        shader->bind();
        shader->set_uniform_4mat("u_view_matrix", m_ortho_view);
    }

    for(Shader* shader : m_perspective_shaders)
    {
        shader->bind();
        shader->set_uniform_4mat("u_view_matrix", m_perspective_view);
    }

}

void Camera::move_forward()
{
    m_position.z += sin(glm::radians(m_angle_x)) * m_speed;
    m_position.x += cos(glm::radians(m_angle_x)) * m_speed;

}

void Camera::move_backward()
{
    m_position.z += sin(glm::radians(m_angle_x - 180)) * m_speed;
    m_position.x += cos(glm::radians(m_angle_x - 180)) * m_speed;
}

void Camera::move_left()
{
    m_position.z += sin(glm::radians(m_angle_x - 90)) * m_speed;
    m_position.x += cos(glm::radians(m_angle_x - 90)) * m_speed;
}

void Camera::move_right()
{
    m_position.z += sin(glm::radians(m_angle_x + 90)) * m_speed;
    m_position.x += cos(glm::radians(m_angle_x + 90)) * m_speed;
}

void Camera::move_up()
{
    m_position.y += m_speed;
}

void Camera::move_down()
{
    m_position.y -= m_speed;
}
