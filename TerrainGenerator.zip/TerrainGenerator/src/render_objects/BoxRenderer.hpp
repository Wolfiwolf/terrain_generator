#pragma once

#include "../graphics/Graphics.hpp"

class BoxRenderer
{
private:
    VertexArray m_vao;

    Shader* m_shader;
    Texture* m_texture;

    glm::mat4 m_model_matrix;

public:
    BoxRenderer();
    ~BoxRenderer();

    void bind();

    void render(const glm::vec3& position);

    inline void set_shader(Shader* shader)
    {
        m_shader = shader;
    }

    inline void set_texture(Texture* texture)
    {
        m_texture = texture;
    }
};
