#pragma once

#include <vector>
#include "../graphics/Shader.hpp"

#include "../Direction.hpp"

#define SCREEN_WIDTH 1280
#define SCREEN_HEIGHT 720

class Camera
{
private:
    glm::vec3 m_position;
    glm::vec3 m_ortho_position;

    float m_speed;

    float m_angle_x;

    glm::mat4 m_ortho_view;
    glm::mat4 m_ortho_proj;

    glm::mat4 m_perspective_view;
    glm::mat4 m_perspective_proj;

    std::vector<Shader*> m_perspective_shaders;
    std::vector<Shader*> m_ortho_shaders;

    glm::vec3 m_front;

public:
    enum ProjectionType
    {
        ORTHO,
        PERSPECTIVE
    };

    Camera(int framebuffer_width, int framebuffer_height);
    ~Camera();

    void update();

    void add_shader(Shader* shader, ProjectionType type);

    void set_position(const glm::vec3& pos);

    void move(Direction dir);

    void look(float x, float y);

    inline void set_speed(float speed)
    {
        m_speed = speed;
    }

    inline const glm::vec3& get_position() const
    {
        return m_position;
    }

    inline const glm::mat4& get_ortho_view() const
    {
        return m_ortho_view;
    }

    inline const glm::mat4& get_ortho_projection() const
    {
        return m_ortho_proj;
    }

private:
    void update_mvp();

    void move_forward();
    void move_backward();
    void move_left();
    void move_right();
    void move_up();
    void move_down();
};
