#pragma once

#include "vendor/glad/glad.h"
#include <GLFW/glfw3.h>

#include "events/Events.hpp"

#include <iostream>
#include <string>
#include <vector>

class Window
{
private:
    int m_width;
    int m_height;

    int m_framebuffer_width;
    int m_framebuffer_height;

    GLFWwindow* m_window;

    static std::vector<Event*> s_events;

public:
    Window(const std::string& title, unsigned int width, unsigned int height);
    ~Window();

    void clear();

    void swap_buffers();

    inline void hide_cursor()
    {
        glfwSetInputMode(m_window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    }

    inline void show_cursor()
    {
        glfwSetInputMode(m_window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
    }

    inline std::vector<Event*>& get_events() const
    {
        return s_events;
    }

    inline int get_framebuffer_width()
    {
        return m_framebuffer_width;
    }

    inline int get_framebuffer_height()
    {
        return m_framebuffer_height;
    }

};
