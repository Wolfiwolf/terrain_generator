#pragma once

#include "Scene.hpp"
#include "../game_objects/blocks/Blocks.hpp"
#include "../terrain_generating/PerlinNoise.hpp"

class GameScene : public Scene
{
private:
    std::vector<Block*> m_all_blocks;
    std::vector<SandBlock*> m_sand_blocks;
    std::vector<DirtBlock*> m_dirt_blocks;
    std::vector<WaterBlock*> m_water_blocks;

    int m_prev_cursor_x;
    int m_prev_cursor_y;

public:
    GameScene();
    ~GameScene();

    void init() override;

    void update() override;

    void on_key_pressed(const KeyPressed* event) override;
    void on_key_released(const KeyReleased* event) override;
    void on_mouse_pressed(const MousePressed* event) override;
    void on_mouse_released(const MouseReleased* event) override;
    void on_mouse_moved(const MouseMoved* event) override;

private:
    void setup_graphics();

    void generate_map(int width);

    void look_around();

    void controls();


};
