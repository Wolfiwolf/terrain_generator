#pragma once

#include "../Window.hpp"

#include <iostream>
#include <map>
#include "../KeyCodes.hpp"

#include "../render_objects/RenderObjects.hpp"

#include "../events/Events.hpp"

#include "../debuging_objects/Timer.hpp"

class Scene
{
private:
    int m_change_scene;
    static int s_cursor_pos_x;
    static int s_cursor_pos_y;

    static std::map<int, bool> s_keys_pressed;


protected:
    Camera m_camera;

    static Window* s_window;

    static float s_delta_time;
public:
    Scene();
    virtual ~Scene();

    virtual void init() = 0;

    virtual void update() = 0;

    bool scene_changed(unsigned int& scene_index);

    inline static void set_window(Window* window)
    {
        s_window = window;
    }

    virtual void on_key_pressed(const KeyPressed* event);
    virtual void on_key_released(const KeyReleased* event);
    virtual void on_mouse_pressed(const MousePressed* event) = 0;
    virtual void on_mouse_released(const MouseReleased* event) = 0;
    virtual void on_mouse_moved(const MouseMoved* event);

private:
    static void fill_key_codes();

protected:


    void change_scene(unsigned int scene_index);

    static bool is_key_pressed(int key_code);

    inline static int get_cursor_pos_x()
    {
        return s_cursor_pos_x;
    }

    inline static int get_cursor_pos_y()
    {
        return s_cursor_pos_y;
    }
};
