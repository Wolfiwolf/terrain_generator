#include "Timer.hpp"

#include <iostream>

std::chrono::high_resolution_clock::time_point Timer::s_start_time;
std::chrono::high_resolution_clock::time_point Timer::s_end_time;

std::chrono::duration<double> Timer::s_duration;

Timer::Timer()
{

}

Timer::~Timer()
{

}

void Timer::start()
{
    s_start_time = std::chrono::high_resolution_clock::now();
}

void Timer::stop()
{
    s_end_time = std::chrono::high_resolution_clock::now();

    s_duration = s_end_time - s_start_time;

}

float Timer::get_duration()
{
    return (s_duration.count() * 1000);
}
