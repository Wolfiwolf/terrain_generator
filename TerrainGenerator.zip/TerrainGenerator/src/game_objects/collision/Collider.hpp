#pragma once

#include "../GameObject.hpp"

class Collider
{
private:
    glm::vec3 m_collider_position;
    glm::vec3 m_collider_size;


protected:
    std::vector<const Collider*> m_collision_objects;

    bool m_obstacle_forth;
    bool m_obstacle_back;
    bool m_obstacle_up;
    bool m_obstacle_down;
    bool m_obstacle_left;
    bool m_obstacle_right;

public:
    Collider(const glm::vec3& position, const glm::vec3& size);
    virtual ~Collider();

    void detect_collision(const Collider* obj);

    inline const glm::vec3& get_collider_pos() const
    {
        return m_collider_position;
    }

    inline const glm::vec3& get_collider_size() const
    {
        return m_collider_size;
    }

protected:
    void update_obstacle_detection();

};
