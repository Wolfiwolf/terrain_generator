#pragma once

#include "collision/Collider.hpp"

class Player : public GameObject, public Collider
{
private:


public:
    Player(const glm::vec3& position);
    ~Player();

    void update();

    inline void set_position(const glm::vec3& position)
    {
        m_position = position;
    }



};
