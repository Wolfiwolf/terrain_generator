#pragma once

#include "../render_objects/RenderObjects.hpp"

class GameObject
{
protected:
    glm::vec3 m_position;

public:
    GameObject(const glm::vec3& position);
    virtual ~GameObject();

    inline const glm::vec3& get_pos() const
    {
        return m_position;
    }

};
