#pragma once

#include "../collision/Collider.hpp"

enum BlockType
{
    SOLID,
    LIQUID
};

class Block : public GameObject, public Collider
{
protected:
    unsigned int m_health;

    std::vector<Block*> m_surrounding_blocks;

public:
    Block(const glm::vec3& position, unsigned int health);
    virtual ~Block();

    virtual void update() = 0;

    virtual BlockType get_type() const = 0;

    void take_damage();

    void add_surrounding_block(Block* block);

    void remove_surrounding_block(Block* block);

};
