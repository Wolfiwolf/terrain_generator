#pragma once

#include "Block.hpp"

class WaterBlock : public Block
{
private:
    static BoxRenderer* s_box;
    static Shader* s_shader;
    static Texture* s_texture;

public:
    WaterBlock(const glm::vec3& position);
    ~WaterBlock();

    void update() override;

    BlockType get_type() const override;

    static void bind_box_renderer();

    static void setup_graphics(Shader* shader);
};
