#include "SandBlock.hpp"
#include <iostream>

BoxRenderer* SandBlock::s_box;
Shader* SandBlock::s_shader;
Texture* SandBlock::s_texture;

SandBlock::SandBlock(const glm::vec3& position)
    : Block::Block(position, 3)
{

}

SandBlock::~SandBlock()
{

}

void SandBlock::update()
{
    s_box->render(m_position);
}

BlockType SandBlock::get_type() const
{
    return SOLID;
}

//STATIC
void SandBlock::bind_box_renderer()
{
    s_box->bind();
}

void SandBlock::setup_graphics(Shader* shader)
{
    s_shader = shader;

    s_texture = new Texture("res/sand_tex.jpg");

    s_box = new BoxRenderer();

    s_box->set_shader(shader);
    s_box->set_texture(s_texture);
}
