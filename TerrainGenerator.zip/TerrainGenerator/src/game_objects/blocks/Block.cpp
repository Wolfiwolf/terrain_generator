#include "Block.hpp"

Block::Block(const glm::vec3& position, unsigned int health)
    : GameObject::GameObject(position)
    , Collider::Collider(position, {0.5f, 0.5f, 0.5f})
    , m_health(health)
{

}

Block::~Block()
{

}

void Block::take_damage()
{
    m_health--;
}

void Block::add_surrounding_block(Block* block)
{
    m_surrounding_blocks.push_back(block);
}

void Block::remove_surrounding_block(Block* block)
{
    for(int i = 0; i < m_surrounding_blocks.size(); i++)
    {
        if(m_surrounding_blocks[i] == block)
        {
            m_surrounding_blocks.erase(m_surrounding_blocks.begin() + i);
            return;
        }
    }
}
