#include "GameObject.hpp"

GameObject::GameObject(const glm::vec3& position)
    : m_position(position)
{

}

GameObject::~GameObject()
{

}
