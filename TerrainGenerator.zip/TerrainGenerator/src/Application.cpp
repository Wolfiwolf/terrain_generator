#include "Application.hpp"

#include "render_objects/BoxRenderer.hpp"
#include "render_objects/Camera.hpp"


Application::Application()
    : m_running(false)
{

}

Application::~Application()
{
    delete m_window;
}



void Application::run()
{

    m_window = new Window("Terrain generator", SCREEN_WIDTH, SCREEN_HEIGHT);


    Scene::set_window(m_window);


    m_scenes[0] = new GameScene;
    m_scenes[0]->init();

    m_scene_index = 0;



    m_running = true;
    while(m_running)
    {
        m_window->clear();

        m_scenes[m_scene_index]->update();

        if(m_scenes[m_scene_index]->scene_changed(m_scene_index))
            m_scenes[m_scene_index]->init();


        m_window->swap_buffers();

        event_handler();
    }
}

//PRIVATE


void Application::event_handler()
{
    std::vector<Event*>& events = m_window->get_events();

    for(Event* event : events)
    {
        switch(event->get_type())
        {
            case WINDOW_CLOSED:
                glfwTerminate();
                m_running = false;
                break;

                case MOUSE_MOVED:
                m_scenes[m_scene_index]->on_mouse_moved((MouseMoved*)event);
                break;

                case MOUSE_PRESSED:
                m_scenes[m_scene_index]->on_mouse_pressed((MousePressed*)event);
                break;

                case MOUSE_RELEASED:
                m_scenes[m_scene_index]->on_mouse_released((MouseReleased*)event);
                break;

                case KEY_PRESSED:
                m_scenes[m_scene_index]->on_key_pressed((KeyPressed*)event);
                break;

                case KEY_RELEASED:
                m_scenes[m_scene_index]->on_key_released((KeyReleased*)event);
                break;

        }

        delete event;
    }

    events.clear();

}
