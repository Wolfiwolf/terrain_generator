#pragma once

#include <iostream>
#include <thread>
#include "Window.hpp"
#include "scenes/Scene.hpp"
#include "scenes/GameScene.hpp"




class Application
{
private:
    bool m_running;

    Window* m_window;

    Scene* m_scenes[10];
    unsigned int m_scene_index;


public:
    Application();
    ~Application();

    void run();

private:
    void event_handler();


};
