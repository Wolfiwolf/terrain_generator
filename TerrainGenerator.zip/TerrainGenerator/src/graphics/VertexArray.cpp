#include "VertexArray.hpp"

VertexArray::VertexArray()
{
    glGenVertexArrays(1, &m_renderer_id);
    glBindVertexArray(m_renderer_id);
}

VertexArray::~VertexArray()
{

}


void VertexArray::bind() const
{
    glBindVertexArray(m_renderer_id);
}

void VertexArray::unbind() const
{
    glBindVertexArray(0);
}

void VertexArray::add_layout(const VertexBufferLayout& layout)
{
    const std::vector<VertexBufferLayoutElement*>& elements = layout.get_elements();

    long unsigned int offset = 0;

    for(int i = 0; i < elements.size(); i++)
    {
        const VertexBufferLayoutElement* element = elements[i];

        glVertexAttribPointer(i, element->count, GL_FLOAT, GL_FALSE, layout.get_stride(), (const void*)offset);
        glEnableVertexAttribArray(i);

        offset += element->count * sizeof(float);
    }
}
