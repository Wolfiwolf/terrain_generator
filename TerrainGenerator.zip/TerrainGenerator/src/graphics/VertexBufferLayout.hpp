#pragma once

#include <vector>

struct VertexBufferLayoutElement
{
    unsigned int count;

    VertexBufferLayoutElement(unsigned int count)
        : count(count)
    {

    }

};

struct VertexBufferLayout
{
private:

    std::vector<VertexBufferLayoutElement*> m_elements;

    unsigned int m_stride;

public:
    VertexBufferLayout()
        : m_stride(0)
    {

    }
    ~VertexBufferLayout()
    {
        for(VertexBufferLayoutElement* element : m_elements)
            delete element;
    }

    void push_floats(unsigned int count)
    {
        m_elements.emplace_back(new VertexBufferLayoutElement(count));

        m_stride += count * sizeof(float);
    }

    inline const std::vector<VertexBufferLayoutElement*>& get_elements() const
    {
        return m_elements;
    }

    inline unsigned int get_stride() const
    {
        return m_stride;
    }
};
