#pragma once

#include "../vendor/glad/glad.h"

#include <string>

class Texture
{
private:
    unsigned int m_renderer_id;

    unsigned int m_texture_index;

    static unsigned int s_texture_count;

public:
    Texture(const std::string& filepath);
    ~Texture();

    void bind() const;

    void unbind() const;

    inline unsigned int get_tex_index() const
    {
        return m_texture_index;
    }

};
