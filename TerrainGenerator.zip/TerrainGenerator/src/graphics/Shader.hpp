#pragma once

#include "../vendor/glad/glad.h"
#include "../vendor/glm/gtc/quaternion.hpp"

#include <string>
#include <map>

struct ShaderSource
{
    std::string vertex_shader;
    std::string fragment_shader;
};

class Shader
{
private:
    unsigned int m_renderer_id;

    std::map<std::string, int> m_uniform_locations;

public:
    Shader(const std::string& filepath);
    ~Shader();

    void bind() const;
    void unbind() const;

    void set_uniform_1i(const std::string& name, int value);
    void set_uniform_4mat(const std::string& name, const glm::mat4& matrix);

private:
    ShaderSource get_shader_source(const std::string& filepath);

    unsigned int compile_shader(const std::string& src, unsigned int type);

    unsigned int create_shader(const ShaderSource& shader_src);

    int get_uniform_location(const std::string& name);
};
