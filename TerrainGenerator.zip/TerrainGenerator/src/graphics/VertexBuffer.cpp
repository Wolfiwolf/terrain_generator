#include "VertexBuffer.hpp"

VertexBuffer::VertexBuffer(unsigned int verticies_count, const float* verticies)
{
    glGenBuffers(1, &m_renderer_id);
    glBindBuffer(GL_ARRAY_BUFFER, m_renderer_id);
    glBufferData(GL_ARRAY_BUFFER, verticies_count * sizeof(float), verticies, GL_STATIC_DRAW);
}

VertexBuffer::~VertexBuffer()
{

}

void VertexBuffer::bind() const
{
    glBindBuffer(GL_ARRAY_BUFFER, m_renderer_id);
}

void VertexBuffer::unbind() const
{
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}
