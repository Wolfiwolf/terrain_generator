#pragma once

#include "../vendor/glad/glad.h"

class VertexBuffer
{
private:
    unsigned int m_renderer_id;

public:
    VertexBuffer(unsigned int verticies_count, const float* verticies);
    ~VertexBuffer();

    void bind() const;
    void unbind() const;

};
