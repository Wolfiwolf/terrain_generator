#include "PerlinNoise.hpp"

#include <random>
#include <cmath>

const int PerlinNoise::primes[10][3];

PerlinNoise::PerlinNoise(int amplitude)
    : m_amplitude(amplitude/3)
{
    srand(time(NULL));

    m_random_offset = rand() % 100000;
}

PerlinNoise::~PerlinNoise()
{

}

int PerlinNoise::get_height_on_position(double x, double y)
{
    x += m_random_offset;
    y += m_random_offset;

    double total = 0;
    double frequency = pow(2, numOctaves);
    double amplitude = 1;

    for (int i = 0; i < numOctaves; ++i)
    {
        frequency /= 2;
        amplitude *= persistence;
        total += interpolated_noise((primeIndex + i) % max_prime_index, x / frequency, y / frequency) * amplitude;
    }

    float return_val = (((total / frequency) * 10) * m_amplitude);

    return return_val;
}


//PRIVATE

double PerlinNoise::noise(int i, int x, int y)
{
    int n = x + y * 57;
    n = (n << 13) ^ n;
    int a = primes[i][0], b = primes[i][1], c = primes[i][2];
    int t = (n * (n * n * a + b) + c) & 0x7fffffff;
    return 1.0 - (double)(t)/1073741824.0;
}

double PerlinNoise::smoothed_noise(int i, int x, int y)
{
    double corners = (noise(i, x-1, y-1) + noise(i, x+1, y-1) + noise(i, x-1, y+1) + noise(i, x+1, y+1)) / 16;
    double sides = (noise(i, x-1, y) + noise(i, x+1, y) + noise(i, x, y-1) + noise(i, x, y+1)) / 8;
    double center = noise(i, x, y) / 4;

    return corners + sides + center;
}

double PerlinNoise::interpolate(double a, double b, double x)
{
    double ft = x * 3.1415927;
    double f = (1 - cos(ft)) * 0.5;

    return  a*(1-f) + b*f;
}

double PerlinNoise::interpolated_noise(int i, double x, double y)
{
    int integer_X = x;
    double fractional_X = x - integer_X;

    int integer_Y = y;
    double fractional_Y = y - integer_Y;

    double v1 = smoothed_noise(i, integer_X, integer_Y);
    double v2 = smoothed_noise(i, integer_X + 1, integer_Y);
    double v3 = smoothed_noise(i, integer_X, integer_Y + 1);
    double v4 = smoothed_noise(i, integer_X + 1, integer_Y + 1);
    double i1 = interpolate(v1, v2, fractional_X);
    double i2 = interpolate(v3, v4, fractional_X);

    return interpolate(i1, i2, fractional_Y);
}
