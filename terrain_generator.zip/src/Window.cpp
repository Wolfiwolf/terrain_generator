#include "Window.hpp"

std::vector<Event*> Window::s_events;

Window::Window(const std::string& title, unsigned int width, unsigned int height)
    : m_width(width)
    , m_height(height)
    , m_framebuffer_width(0)
    , m_framebuffer_height(0)
    , m_window(NULL)
{

    if (!glfwInit())
    {
        std::cout << "GLFW init failed!\n";
        return;
    }


    glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
    m_window = glfwCreateWindow(m_width, m_height, title.c_str(), NULL, NULL);
    if (!m_window)
    {
        std::cout << "Window failed!\n";
        glfwTerminate();
        return;
    }

    glfwMakeContextCurrent(m_window);

    glfwWindowHint(GLFW_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    if(!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
        std::cout << "GLAD failed!\n";


    glfwGetFramebufferSize(m_window, &m_framebuffer_width, &m_framebuffer_height);
    glViewport(0, 0, m_framebuffer_width, m_framebuffer_height);

    glfwSwapInterval(1);
    glEnable(GL_DEPTH_TEST);

    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);


    glfwSetWindowCloseCallback(m_window, [](GLFWwindow*)
    {
        s_events.emplace_back(new WindowClosedEvent);
    });

    glfwSetCursorPosCallback(m_window, [](GLFWwindow*, double x_pos, double y_pos)
    {
        s_events.emplace_back(new MouseMoved((int)x_pos, (int)y_pos));
    });


    glfwSetMouseButtonCallback(m_window, [](GLFWwindow*, int button, int action,int)
    {
        if(action == 1)
            s_events.emplace_back(new MousePressed(button));
        else if(action == 0)
            s_events.emplace_back(new MouseReleased(button));
        else
            std::cout << "OJOOJJ\n";

    });

    glfwSetKeyCallback(m_window, [](GLFWwindow*, int keycode, int , int action, int)
    {
        if(action == 1)
            s_events.emplace_back(new KeyPressed(keycode));
        else
            s_events.emplace_back(new KeyReleased(keycode));

    });


    glClearColor(0.5f, 0.5f, 1.0f, 1.0f);
    system("xset r off");
}

Window::~Window()
{
    glfwTerminate();
    system("xset r on");
}

void Window::clear()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
}

void Window::swap_buffers()
{
    glfwSwapBuffers(m_window);

    glfwPollEvents();

    glFlush();
}
