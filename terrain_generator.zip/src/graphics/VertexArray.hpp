#pragma once

#include "../vendor/glad/glad.h"

#include "VertexBufferLayout.hpp"

class VertexArray
{
private:
    unsigned int m_renderer_id;

public:
    VertexArray();
    ~VertexArray();

    void bind() const;

    void unbind() const;

    void add_layout(const VertexBufferLayout& layout);


};
