#include "Shader.hpp"

#include <iostream>
#include <fstream>
#include <sstream>

Shader::Shader(const std::string& filepath)
{

    ShaderSource shader_src = get_shader_source(filepath);

    m_renderer_id = create_shader(shader_src);

    glUseProgram(m_renderer_id);
}
Shader::~Shader()
{

}

void Shader::bind() const
{
    glUseProgram(m_renderer_id);
}

void Shader::unbind() const
{
    glUseProgram(0);
}

void Shader::set_uniform_1i(const std::string& name, int value)
{
    int location = get_uniform_location(name);

    glUniform1i(location, value);
}

void Shader::set_uniform_4mat(const std::string& name, const glm::mat4& matrix)
{
    int location = get_uniform_location(name);

    glUniformMatrix4fv(location, 1, GL_FALSE, &matrix[0][0]);
}

//PRIVATE

ShaderSource Shader::get_shader_source(const std::string& filepath)
{
    std::stringstream ss[2];

    std::ifstream in_file(filepath);
    if(!in_file.is_open())
    {
        std::cout << "ERROR: Can't open filepath '" << filepath << "'!\n";
        return {"", ""};
    }

    enum ShaderType
    {
        VERTEX = 0,
        FRAGMENT
    };

    ShaderType type = VERTEX;

    std::string line;
    while(std::getline(in_file, line))
    {
        if(line.find("#FRAGMENT SHADER") != std::string::npos)
        {
            type = FRAGMENT;
        }
        else if(line.find("#VERTEX SHADER") != std::string::npos)
        {
            type = VERTEX;
        }
        else
        {
            ss[type] << line << "\n";
        }

    }


    return {ss[VERTEX].str(), ss[FRAGMENT].str()};
}

unsigned int Shader::compile_shader(const std::string& src, unsigned int type)
{
    unsigned int id = glCreateShader(type);

    const char* src_cc = src.c_str();

    glShaderSource(id, 1, &src_cc, nullptr);

    glCompileShader(id);

    GLint success = 0;
    glGetShaderiv(id, GL_COMPILE_STATUS, &success);

    if(success == GL_FALSE)
    {
        GLint log_size = 0;
        glGetShaderiv(id, GL_INFO_LOG_LENGTH, &log_size);
        char log[log_size];

        glGetShaderInfoLog(id, log_size, &log_size, log);

        std::cout << "ERROR: " << (type == GL_VERTEX_SHADER ? "VERTEX":"FRAGMENT") <<  " SHADER!\n" << log << "\n";

    }

    return id;
}

unsigned int Shader::create_shader(const ShaderSource& shader_src)
{
    const std::string& vs_src = shader_src.vertex_shader;
    const std::string& fs_src = shader_src.fragment_shader;

    unsigned int vs = compile_shader(vs_src, GL_VERTEX_SHADER);
    unsigned int fs = compile_shader(fs_src, GL_FRAGMENT_SHADER);

    unsigned int program = glCreateProgram();

    glAttachShader(program, vs);
    glAttachShader(program, fs);

    glLinkProgram(program);

    glValidateProgram(program);

    glDeleteShader(vs);
    glDeleteShader(fs);

    return program;
}

int Shader::get_uniform_location(const std::string& name)
{
    if(m_uniform_locations.find(name) == m_uniform_locations.end())
        m_uniform_locations.insert({name, glGetUniformLocation(m_renderer_id, name.c_str())});

    int location = m_uniform_locations[name];

    if(location == -1)
        std::cout << "Uniform '" << name << "' doesn't exist!\n";

    return location;
}
