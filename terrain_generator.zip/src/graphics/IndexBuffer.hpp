#pragma once

#include "../vendor/glad/glad.h"

class IndexBuffer
{
private:
    unsigned int m_renderer_id;

public:
    IndexBuffer(unsigned int indicies_count, const unsigned int* indicies);
    ~IndexBuffer();

    void bind() const;
    void unbind() const;

};
