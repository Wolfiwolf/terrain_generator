#pragma once

#include <chrono>

class Timer
{
private:
    static std::chrono::high_resolution_clock::time_point s_start_time;
    static std::chrono::high_resolution_clock::time_point s_end_time;

    static std::chrono::duration<double> s_duration;

public:
    Timer();
    ~Timer();

    static void start();

    static void stop();

    static float get_duration();
};
