#include "GameScene.hpp"

#include <random>

GameScene::GameScene()
{

    setup_graphics();

    generate_map(500);


}
GameScene::~GameScene()
{
    for(Block* block : m_all_blocks)
        delete block;

}

void GameScene::init()
{
    s_window->hide_cursor();

    m_camera.set_position({0.0f, 20.0f, 0.0f});


    m_prev_cursor_x = get_cursor_pos_x();
    m_prev_cursor_y = get_cursor_pos_y();

}

void GameScene::update()
{

    SandBlock::bind_box_renderer();
    for(SandBlock* block : m_sand_blocks)
    {
        if(abs(block->get_pos().x - m_camera.get_position().x) > 70.0f || abs(block->get_pos().z - m_camera.get_position().z) > 70.0f)
            continue;
        block->update();
    }

    DirtBlock::bind_box_renderer();
    for(DirtBlock* block : m_dirt_blocks)
    {
        if(abs(block->get_pos().x - m_camera.get_position().x) > 70.0f || abs(block->get_pos().z - m_camera.get_position().z) > 70.0f)
            continue;
        block->update();
    }

    WaterBlock::bind_box_renderer();
    for(WaterBlock* block : m_water_blocks)
    {
        if(abs(block->get_pos().x - m_camera.get_position().x) > 70.0f || abs(block->get_pos().z - m_camera.get_position().z) > 70.0f)
            continue;
        block->update();
    }




    m_camera.update();

    look_around();
    controls();


    Timer::stop();

    s_delta_time = Timer::get_duration();
    s_delta_time *= 0.01f;


    m_camera.set_speed(0.5f * s_delta_time);

    Timer::start();

}


void GameScene::on_key_pressed(const KeyPressed* event)
{

    static bool cursor_is_showing = false;

    if(event->get_keycode() == KEY_ESCAPE)
    {
        if(!cursor_is_showing)
        {
            s_window->show_cursor();
            cursor_is_showing = true;
        }
        else
        {
            s_window->hide_cursor();
            cursor_is_showing = false;
        }
    }


}

void GameScene::on_key_released(const KeyReleased* event)
{

}

void GameScene::on_mouse_pressed(const MousePressed* event)
{

}

void GameScene::on_mouse_released(const MouseReleased* event)
{

}

void GameScene::on_mouse_moved(const MouseMoved* event)
{
    Scene::on_mouse_moved(event);




}

//PRIVATE

void GameScene::setup_graphics()
{
    Shader* shader3D = new Shader("shaders/Shader3D.glsl");

    DirtBlock::setup_graphics(shader3D);
    SandBlock::setup_graphics(shader3D);
    WaterBlock::setup_graphics(shader3D);

    m_camera.add_shader(shader3D, Camera::PERSPECTIVE);
}



void GameScene::generate_map(int width)
{


    PerlinNoise perlin_noise(50);

    int half_width = width/2;

    std::vector<float> noises;
    noises.reserve(100000);

    for(int i = -half_width; i < half_width; i++)
    {
        int x;
        int y;
        int z;
        for(int p = -half_width; p < half_width; p++)
        {

            x = p;
            y = perlin_noise.get_height_on_position(i, p);
            z = i;

            if(y < -18.0f)
            {
                m_sand_blocks.emplace_back(new SandBlock({x, y, z}));
                m_water_blocks.emplace_back(new WaterBlock({x, -16.0f, z}));

            }

            else if(y < -15.0f)
            {
                SandBlock* sand_block = new SandBlock({x, -16.0f, z});

                m_sand_blocks.push_back(sand_block);
                m_all_blocks.push_back(sand_block);

            }
            else
            {
                DirtBlock* dirt_block = new DirtBlock({x, y, z});
                DirtBlock* dirt_block_2 = new DirtBlock({x, y-1, z});

                m_dirt_blocks.push_back(dirt_block);
                m_dirt_blocks.push_back(dirt_block_2);

                m_all_blocks.push_back(dirt_block);
                m_all_blocks.push_back(dirt_block_2);
            }

        }
    }


}

void GameScene::look_around()
{
    float x = get_cursor_pos_x() - m_prev_cursor_x;
    float y = m_prev_cursor_y - get_cursor_pos_y();

    m_camera.look(x * 0.1f, y * 0.003f);

    m_prev_cursor_x = get_cursor_pos_x();
    m_prev_cursor_y = get_cursor_pos_y();
}

void GameScene::controls()
{
    if(is_key_pressed(KEY_D))
        m_camera.move(RIGHT);

    if(is_key_pressed(KEY_A))
        m_camera.move(LEFT);

    if(is_key_pressed(KEY_W))
        m_camera.move(FORWARD);

    if(is_key_pressed(KEY_S))
        m_camera.move(BACKWARD);

    if(is_key_pressed(KEY_SPACE))
        m_camera.move(UP);

    if(is_key_pressed(KEY_LEFT_SHIFT))
        m_camera.move(DOWN);
}
