#include "Scene.hpp"

int Scene::s_cursor_pos_x = 0;
int Scene::s_cursor_pos_y = 0;

Window* Scene::s_window;

float Scene::s_delta_time;

Scene::Scene()
    : m_change_scene(-1)
    , m_camera(s_window->get_framebuffer_width(), s_window->get_framebuffer_height())
{

}

Scene::~Scene()
{

}


bool Scene::scene_changed(unsigned int& scene_index)
{
    if(m_change_scene == -1)
        return false;

    scene_index = m_change_scene;
    m_change_scene = -1;
    return true;
}


//PROTECTED


void Scene::on_mouse_moved(const MouseMoved* event)
{
    s_cursor_pos_x = event->get_x_pos();
    s_cursor_pos_y = event->get_y_pos();
}

bool Scene::is_key_pressed(int key_code)
{

    return glfwGetKey(s_window->get_window(), key_code) == GLFW_PRESS;
}

void Scene::change_scene(unsigned int scene_index)
{
    m_change_scene = scene_index;
}
