#include "DirtBlock.hpp"
#include <iostream>

BoxRenderer* DirtBlock::s_box;
Shader* DirtBlock::s_shader;
Texture* DirtBlock::s_texture;

DirtBlock::DirtBlock(const glm::vec3& position)
    : Block::Block(position, 3)
{

}

DirtBlock::~DirtBlock()
{

}

void DirtBlock::update()
{
    s_box->render(m_position);
}

BlockType DirtBlock::get_type() const
{
    return SOLID;
}

//STATIC
void DirtBlock::bind_box_renderer()
{
    s_box->bind();
}

void DirtBlock::setup_graphics(Shader* shader)
{
    s_shader = shader;

    s_texture = new Texture("res/dirt_tex.jpg");

    s_box = new BoxRenderer();

    s_box->set_shader(shader);
    s_box->set_texture(s_texture);
}
