#include "WaterBlock.hpp"
#include <iostream>

BoxRenderer* WaterBlock::s_box;
Shader* WaterBlock::s_shader;
Texture* WaterBlock::s_texture;

WaterBlock::WaterBlock(const glm::vec3& position)
    : Block::Block(position, 3)
{

}

WaterBlock::~WaterBlock()
{

}

void WaterBlock::update()
{
    s_box->render(m_position);
}

BlockType WaterBlock::get_type() const
{
    return LIQUID;
}

//STATIC
void WaterBlock::bind_box_renderer()
{
    s_box->bind();
}

void WaterBlock::setup_graphics(Shader* shader)
{
    s_shader = shader;

    s_texture = new Texture("res/water_tex.jpeg");

    s_box = new BoxRenderer();

    s_box->set_shader(shader);
    s_box->set_texture(s_texture);
}
