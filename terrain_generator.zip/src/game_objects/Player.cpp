#include "Player.hpp"

Player::Player(const glm::vec3& position)
    : GameObject::GameObject(position)
    , Collider::Collider(position, {0.1f, 1.0f, 0.1f})
{

}

Player::~Player()
{

}

void Player::update()
{
    update_obstacle_detection();



}
