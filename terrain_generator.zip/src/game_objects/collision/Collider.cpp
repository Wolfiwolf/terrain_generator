#include "Collider.hpp"

Collider::Collider(const glm::vec3& position, const glm::vec3& size)
    : m_collider_position(position)
    , m_collider_size(size)
{
    m_collision_objects.reserve(30);
}

Collider::~Collider()
{

}

void Collider::detect_collision(const Collider* obj)
{
    m_collision_objects.push_back(obj);
}


//PROTECTED
void Collider::update_obstacle_detection()
{
    if(m_collision_objects.empty())
        return;

    m_obstacle_forth = false;
    m_obstacle_back = false;
    m_obstacle_up = false;
    m_obstacle_down = false;
    m_obstacle_left = false;
    m_obstacle_right = false;

    for(const Collider* obj : m_collision_objects)
    {
        
    }
}
