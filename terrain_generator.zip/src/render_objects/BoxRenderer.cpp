#include "BoxRenderer.hpp"



BoxRenderer::BoxRenderer()
    : m_shader(nullptr)
    , m_texture(nullptr)
{
    constexpr const float verticies[(8 * 4) * 6] =
    {
         -0.5f, -0.5f,  0.5f,   0.0f, 0.0f,     0.0f, 0.0f, 1.0f,
          0.5f, -0.5f,  0.5f,   1.0f, 0.0f,     0.0f, 0.0f, 1.0f,
          0.5f,  0.5f,  0.5f,   1.0f, 1.0f,     0.0f, 0.0f, 1.0f,
         -0.5f,  0.5f,  0.5f,   0.0f, 1.0f,     0.0f, 0.0f, 1.0f,

         -0.5f, -0.5f, -0.5f,   0.0f, 0.0f,    -1.0f, 0.0f, 0.0f,
         -0.5f, -0.5f,  0.5f,   1.0f, 0.0f,    -1.0f, 0.0f, 0.0f,
         -0.5f,  0.5f,  0.5f,   1.0f, 1.0f,    -1.0f, 0.0f, 0.0f,
         -0.5f,  0.5f, -0.5f,   0.0f, 1.0f,    -1.0f, 0.0f, 0.0f,

          0.5f, -0.5f, -0.5f,   0.0f, 0.0f,     0.0f, 0.0f, -1.0f,
         -0.5f, -0.5f, -0.5f,   1.0f, 0.0f,     0.0f, 0.0f, -1.0f,
         -0.5f,  0.5f, -0.5f,   1.0f, 1.0f,     0.0f, 0.0f, -1.0f,
          0.5f,  0.5f, -0.5f,   0.0f, 1.0f,     0.0f, 0.0f, -1.0f,

          0.5f, -0.5f,  0.5f,   0.0f, 0.0f,     1.0f, 0.0f, 0.0f,
          0.5f, -0.5f, -0.5f,   1.0f, 0.0f,     1.0f, 0.0f, 0.0f,
          0.5f,  0.5f, -0.5f,   1.0f, 1.0f,     1.0f, 0.0f, 0.0f,
          0.5f,  0.5f,  0.5f,   0.0f, 1.0f,     1.0f, 0.0f, 0.0f,

         -0.5f,  0.5f,  0.5f,   0.0f, 0.0f,     0.0f, 1.0f, 0.0f,
          0.5f,  0.5f,  0.5f,   1.0f, 0.0f,     0.0f, 1.0f, 0.0f,
          0.5f,  0.5f, -0.5f,   1.0f, 1.0f,     0.0f, 1.0f, 0.0f,
         -0.5f,  0.5f, -0.5f,   0.0f, 1.0f,     0.0f, 1.0f, 0.0f,

         -0.5f, -0.5f, -0.5f,   0.0f, 0.0f,     0.0f, -1.0f, 0.0f,
          0.5f, -0.5f, -0.5f,   1.0f, 0.0f,     0.0f, -1.0f, 0.0f,
          0.5f, -0.5f,  0.5f,   1.0f, 1.0f,     0.0f, -1.0f, 0.0f,
         -0.5f, -0.5f,  0.5f,   0.0f, 1.0f,     0.0f, -1.0f, 0.0f
    };

    constexpr const unsigned int indicies[36] =
    {
        0, 1, 2,
        0, 2, 3,

        4, 5, 6,
        4, 6, 7,

        8, 9, 10,
        8, 10, 11,

        12, 13, 14,
        12, 14, 15,

        16, 17, 18,
        16, 18, 19,

        20, 21, 22,
        20, 22, 23
    };


    m_vao.bind();

    VertexBuffer vb((8 * 4) * 6, verticies);

    VertexBufferLayout layout;

    layout.push_floats(3);
    layout.push_floats(2);
    layout.push_floats(3);

    m_vao.add_layout(layout);

    IndexBuffer ib(36, indicies);

}

BoxRenderer::~BoxRenderer()
{
    delete m_shader;
    delete m_texture;
}

void BoxRenderer::bind()
{
    m_vao.bind();
    m_shader->bind();

    m_texture->bind();
    m_shader->set_uniform_1i("u_texture", m_texture->get_tex_index());
}

void BoxRenderer::render(const glm::vec3& position)
{
    m_model_matrix = glm::translate(glm::mat4(1.0f), position);

    m_shader->set_uniform_4mat("u_model_matrix", m_model_matrix);

    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, nullptr);

}
