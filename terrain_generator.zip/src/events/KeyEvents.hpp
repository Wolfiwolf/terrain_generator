#pragma once

#include "Event.hpp"


class KeyPressed : public Event
{
private:
    int m_keycode;

public:
    KeyPressed(int keycode)
        : m_keycode(keycode)
    {

    }
    ~KeyPressed()
    {

    }

    std::string to_string() const
    {
        return {"Key pressed => " + std::to_string(m_keycode)};
    }

    EventType get_type() const
    {
        return KEY_PRESSED;
    }

    inline int get_keycode() const
    {
        return m_keycode;
    }

};

class KeyReleased : public Event
{
private:
    int m_keycode;

public:
    KeyReleased(int keycode)
        : m_keycode(keycode)
    {

    }
    ~KeyReleased()
    {

    }

    std::string to_string() const
    {
        return {"Key released => " + std::to_string(m_keycode)};
    }

    EventType get_type() const
    {
        return KEY_RELEASED;
    }

    inline int get_keycode() const
    {
        return m_keycode;
    }
};
