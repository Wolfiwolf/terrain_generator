#pragma once

#include "Event.hpp"

class MouseMoved : public Event
{
private:
    int m_x_pos;
    int m_y_pos;

public:
    MouseMoved(int x_pos, int y_pos)
        : m_x_pos(x_pos)
        , m_y_pos(y_pos)
    {

    }
    ~MouseMoved()
    {

    }

    std::string to_string() const
    {
        return {"Mouse moved => " + std::to_string(m_x_pos) + ", " + std::to_string(m_y_pos)};
    }

    EventType get_type() const
    {
        return MOUSE_MOVED;
    }

    inline int get_x_pos() const
    {
        return m_x_pos;
    }

    inline int get_y_pos() const
    {
        return m_y_pos;
    }

};

class MousePressed : public Event
{
private:
    int m_button;

public:
    MousePressed(int button)
        : m_button(button)
    {

    }
    ~MousePressed()
    {

    }

    std::string to_string() const
    {
        std::string button = m_button == 0 ? "LEFT":"RIGHT";
        return {"Mouse pressed => " + button};
    }

    EventType get_type() const
    {
        return MOUSE_PRESSED;
    }

};

class MouseReleased : public Event
{
private:
    int m_button;

public:
    MouseReleased(int button)
        : m_button(button)
    {

    }
    ~MouseReleased()
    {

    }

    std::string to_string() const
    {
        std::string button = m_button == 0 ? "LEFT":"RIGHT";
        return {"Mouse released => " + button};
    }

    EventType get_type() const
    {
        return MOUSE_PRESSED;
    }

};
