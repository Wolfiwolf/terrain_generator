#pragma once

#include "Event.hpp"

class WindowClosedEvent : public Event
{
public:
    WindowClosedEvent()
    {

    }
    ~WindowClosedEvent()
    {

    }

    std::string to_string() const
    {
        return {"Window closed!"};
    }

    EventType get_type() const
    {
        return WINDOW_CLOSED;
    }
};
