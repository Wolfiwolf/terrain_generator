#pragma once

enum Direction
{
    NONE = -1,
    UP,
    DOWN,
    LEFT,
    RIGHT,
    FORWARD,
    BACKWARD
};
